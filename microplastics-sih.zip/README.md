# Microplastics Detection — SIH (YOLOv8)
**Microplastics detection & analysis** using YOLOv8 for the Smart India Hackathon (SIH) pipeline.

## Quickstart
1. Clone:
```bash
git clone https://github.com/<your-org>/microplastics-sih.git
cd microplastics-sih
```
2. Install deps:
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```
3. Run demo:
```bash
python src/detect.py --weights yolov8n.pt --source data/images --out outputs/
```
