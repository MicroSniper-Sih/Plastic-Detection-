import argparse
from ultralytics import YOLO
import cv2
import os
from src.utils import ensure_dir, classify_polymer_by_rgb

def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--weights", default="yolov8n.pt")
    p.add_argument("--source", default="data/images")
    p.add_argument("--out", default="outputs")
    p.add_argument("--conf", type=float, default=0.25)
    return p.parse_args()

def main():
    args = parse_args()
    model = YOLO(args.weights)
    ensure_dir(args.out)

    image_files = []
    for root, _, files in os.walk(args.source):
        for f in files:
            if f.lower().endswith(('.png','.jpg','.jpeg','.tif','.tiff')):
                image_files.append(os.path.join(root, f))

    for fpath in image_files:
        img = cv2.imread(fpath)
        if img is None:
            continue
        res = model.predict(img, conf=args.conf, verbose=False)
        count = 0
        polymer_counts = {}
        for box in res[0].boxes:
            count += 1
            x1, y1, x2, y2 = box.xyxy[0].cpu().numpy().astype(int)
            roi = img[max(y1,0):y2, max(x1,0):x2]
            if roi.size == 0:
                continue
            mean = cv2.mean(roi)[:3]
            poly = classify_polymer_by_rgb(mean)
            polymer_counts[poly] = polymer_counts.get(poly, 0) + 1
            cv2.rectangle(img, (x1,y1), (x2,y2), (0,255,0), 2)
            cv2.putText(img, poly, (x1, max(0,y1-5)), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255,0,0), 1)

        out_path = os.path.join(args.out, os.path.basename(fpath))
        cv2.imwrite(out_path, img)
        print(f"Processed {fpath} -> {out_path} | count={count} | polymers={polymer_counts}")

if __name__ == "__main__":
    main()
