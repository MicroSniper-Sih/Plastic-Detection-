import os
import cv2

def ensure_dir(path):
    os.makedirs(path, exist_ok=True)

def classify_polymer_by_rgb(pixel):
    r, g, b = pixel[:3]
    if r > g and r > b:
        return "PS"
    elif g > r and g > b:
        return "PE"
    elif b > r and b > g:
        return "PP"
    else:
        return "Other"
