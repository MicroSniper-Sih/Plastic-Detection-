import argparse
from ultralytics import YOLO

def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--data", required=True)
    p.add_argument("--cfg", default="yolov8n.yaml")
    p.add_argument("--epochs", type=int, default=50)
    p.add_argument("--batch", type=int, default=8)
    return p.parse_args()

def main():
    args = parse_args()
    model = YOLO(args.cfg)
    model.train(data=args.data, epochs=args.epochs, batch=args.batch)

if __name__ == "__main__":
    main()
