Place images and labels in YOLOv8 format here.
