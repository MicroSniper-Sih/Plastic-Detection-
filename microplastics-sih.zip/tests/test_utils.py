from src.utils import classify_polymer_by_rgb

def test_classify_polymer_by_rgb():
    assert classify_polymer_by_rgb((200,10,10)) == "PS"
    assert classify_polymer_by_rgb((10,200,10)) == "PE"
    assert classify_polymer_by_rgb((10,10,200)) == "PP"
    assert classify_polymer_by_rgb((50,50,50)) == "Other"
